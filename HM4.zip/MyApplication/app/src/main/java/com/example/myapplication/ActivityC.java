package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;

public class ActivityC extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_c);

        Button openActA = findViewById(R.id.OpenActA);
        openActA.setOnClickListener(view -> {
            Intent intent = new Intent();
            startActivity(intent);
        });

        Button openActD = findViewById(R.id.OpenActD);
        openActD.setOnClickListener(view -> {
            Intent intent = new Intent();
            finishAffinity();
            startActivity(intent);
        });

        Button closeActC = findViewById(R.id.CloseActC);
        closeActC.setOnClickListener(view -> {
            Intent intent = new Intent();
            startActivity(intent);
        });

        Button closeStack = findViewById(R.id.CloseStack);
        closeStack.setOnClickListener(view -> finishAffinity());

    }
}